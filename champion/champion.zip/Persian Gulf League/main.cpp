# include <stdio.h>
# include <fstream>
# include <string>
# include <string.h>
# include "dirent.h"
# include <time.h>
# include <stdlib.h>

using namespace std;

struct player
{
	unsigned int number;
	char name[30];
	int age;
	char type;
	char playingType;
	int skill;
	int fitness;
	int form;
};

const int maxN = 100;

struct team
{
	char name[30];
	int score;
	int tafazol;
	int goalzade;
	int goalkhorde;
	int goalpermatch[30];
	int numberOfWin;
	int numberOfLoose;
	int numberOfEqual;
	int gSize, dSize, mSize, aSize;
	char plan[10];

	player g[maxN];
	player d[maxN];
	player m[maxN];
	player a[maxN];



	int gSize_zakhire, dSize_zakhire, mSize_zakhire, aSize_zakhire;

	player g_zakhire[maxN];
	player d_zakhire[maxN];
	player m_zakhire[maxN];
	player a_zakhire[maxN];


	int gSize_asli, dSize_asli, mSize_asli, aSize_asli;

	player g_asli[maxN];
	player d_asli[maxN];
	player m_asli[maxN];
	player a_asli[maxN];
};

struct schedul
{
	int team1Index;
	int team2Index;
};

team T[maxN];
team T1[maxN];
int teamSize = 0;

int main()
{
	DIR *pDIR;
	struct dirent *entry;
	if (pDIR = opendir("Teams\\")) {
		while (entry = readdir(pDIR)) {
			if (strcmp(entry->d_name, ".") != 0 && strcmp(entry->d_name, "..") != 0)
			{
				string tmp = entry->d_name;
				if (tmp.find(".csv") != std::string::npos)
				{
					team t1;
					strcpy(t1.plan, "4-4-2");
					t1.aSize = 0;
					t1.dSize = 0;
					t1.mSize = 0;
					t1.gSize = 0;
					t1.aSize_zakhire = 0;
					t1.dSize_zakhire = 0;
					t1.mSize_zakhire = 0;
					t1.gSize_zakhire = 0;
					t1.aSize_asli = 0;
					t1.dSize_asli = 0;
					t1.mSize_asli = 0;
					t1.gSize_asli = 0;
					for (int i = 0; i < 30; i++)
						t1.goalpermatch[i] = 0;
					t1.score = 0;
					t1.tafazol = 0;
					t1.goalzade = 0;
					t1.goalkhorde = 0;
					t1.numberOfEqual = 0;
					t1.numberOfLoose = 0;
					t1.numberOfWin = 0;
					ifstream fin("Teams\\" + tmp);
					if (!fin.is_open())
					{
						printf("file not found\n");
						system("pause");
					}
					tmp.pop_back();
					tmp.pop_back();
					tmp.pop_back();
					tmp.pop_back();
					strcpy(t1.name, tmp.data());
					//t1.name = tmp;
					while (!fin.eof())
					{
						string tmp1;
						getline(fin, tmp1);
						if (tmp1.size() == 0)
							break;
						player p1;
						string name1 = tmp1;
						name1.pop_back();
						name1.pop_back();
						p1.skill = (rand() % 50) + 50;
						p1.fitness = (rand() % 50) + 50;
						p1.form = (rand() % 20) + 80;
						p1.type = tmp1.back();
						p1.playingType = tmp1.back();
						if (p1.type == 'G')
						{
							if (tmp1[1] == ',')
							{
								p1.number = tmp1[0] - '0';
							}
							else
							{
								name1.erase(name1.begin());
								p1.number = (tmp1[0] - '0') * 10 + (tmp1[1] - '0');
							}

							if (name1[name1.size() - 3] == ',')
							{
								p1.age = (name1[name1.size() - 2] - '0') * 10 + (name1[name1.size() - 1] - '0');
								name1.pop_back();
							}
							else
							{
								p1.age = (name1[name1.size() - 2] - '0');
							}
							name1.erase(name1.begin());
							// if dovomi adad bud 
							name1.erase(name1.begin());
							name1.pop_back();
							name1.pop_back();
							//p1.name = name1;
							strcpy(p1.name, name1.data());
							t1.g[t1.gSize++] = p1;
						}
						else if (p1.type == 'D')
						{
							if (tmp1[1] == ',')
							{
								p1.number = tmp1[0] - '0';
							}
							else
							{
								name1.erase(name1.begin());
								p1.number = (tmp1[0] - '0') * 10 + (tmp1[1] - '0');
							}

							if (name1[name1.size() - 3] == ',')
							{
								p1.age = (name1[name1.size() - 2] - '0') * 10 + (name1[name1.size() - 1] - '0');
								name1.pop_back();
							}
							else
							{
								p1.age = (name1[name1.size() - 2] - '0');
							}
							name1.erase(name1.begin());
							name1.erase(name1.begin());
							name1.pop_back();
							name1.pop_back();
							//p1.name = name1;
							strcpy(p1.name, name1.data());
							t1.d[t1.dSize++] = p1;
						}
						else if (p1.type == 'M')
						{
							if (tmp1[1] == ',')
							{
								p1.number = tmp1[0] - '0';
							}
							else
							{
								name1.erase(name1.begin());
								p1.number = (tmp1[0] - '0') * 10 + (tmp1[1] - '0');
							}

							if (name1[name1.size() - 3] == ',')
							{
								p1.age = (name1[name1.size() - 2] - '0') * 10 + (name1[name1.size() - 1] - '0');
								name1.pop_back();
							}
							else
							{
								p1.age = (name1[name1.size() - 2] - '0');
							}
							name1.erase(name1.begin());
							name1.erase(name1.begin());
							name1.pop_back();
							name1.pop_back();
							//p1.name = name1;
							strcpy(p1.name, name1.data());
							t1.m[t1.mSize++] = p1;
						}
						else if (p1.type == 'A')
						{
							if (tmp1[1] == ',')
							{
								p1.number = tmp1[0] - '0';
							}
							else
							{
								name1.erase(name1.begin());
								p1.number = (tmp1[0] - '0') * 10 + (tmp1[1] - '0');
							}

							if (name1[name1.size() - 3] == ',')
							{
								p1.age = (name1[name1.size() - 2] - '0') * 10 + (name1[name1.size() - 1] - '0');
								name1.pop_back();
							}
							else
							{
								p1.age = (name1[name1.size() - 2] - '0');
							}
							name1.erase(name1.begin());
							name1.erase(name1.begin());
							name1.pop_back();
							name1.pop_back();
							//p1.name = name1;
							strcpy(p1.name, name1.data());
							t1.a[t1.aSize++] = p1;
						}
					}
					fin.close();
					for (; t1.aSize_asli < 2 && t1.aSize_asli < t1.aSize; t1.aSize_asli++)
					{
						t1.a_asli[t1.aSize_asli] = t1.a[t1.aSize_asli];
					}
					if (t1.aSize_asli == 2)
					{
						for (t1.aSize_zakhire = 0; t1.aSize_zakhire < t1.aSize - t1.aSize_asli ; t1.aSize_zakhire++)
						{
							t1.a_zakhire[t1.aSize_zakhire] = t1.a[t1.aSize_zakhire + 2];
						}
					}

					for (; t1.dSize_asli < 4 && t1.dSize_asli < t1.dSize; t1.dSize_asli++)
					{
						t1.d_asli[t1.dSize_asli] = t1.d[t1.dSize_asli];
					}
					if (t1.dSize_asli == 4)
					{
						for (t1.dSize_zakhire = 0; t1.dSize_zakhire <t1.dSize -t1.dSize_asli ; t1.dSize_zakhire++)
						{
							t1.d_zakhire[t1.dSize_zakhire] = t1.d[t1.dSize_zakhire + 2];
						}
					}

					for (; t1.mSize_asli < 4 && t1.mSize_asli < t1.mSize; t1.mSize_asli++)
					{
						t1.m_asli[t1.mSize_asli] = t1.m[t1.mSize_asli];
					}
					if (t1.mSize_asli == 4)
					{
						for (t1.mSize_zakhire = 0; t1.mSize_zakhire < t1.mSize - t1.mSize_asli; t1.mSize_zakhire++)
						{
							t1.m_zakhire[t1.mSize_zakhire] = t1.m[t1.mSize_zakhire + 4];
						}
					}
					if (t1.gSize != 0)
						t1.g_asli[t1.gSize_asli++] = t1.g[0];
					for (t1.gSize_zakhire = 0; t1.gSize_zakhire < t1.gSize - t1.gSize_asli; t1.gSize_zakhire++)
					{
						t1.g_zakhire[t1.gSize_zakhire] = t1.g[t1.gSize_zakhire + 1];
					}
					while (t1.aSize_asli < 2)
					{
						if (t1.mSize_zakhire > 0)
						{
							t1.a_asli[t1.aSize_asli++] = t1.m_zakhire[--t1.mSize_zakhire];
								t1.a_asli[t1.aSize_asli - 1].playingType = 'A';
						}
						else if (t1.dSize_zakhire > 0)
						{
							t1.a_asli[t1.aSize_asli++] = t1.d_zakhire[--t1.dSize_zakhire];
							t1.a_asli[t1.aSize_asli - 1].playingType = 'A';

						}
						else if (t1.gSize_zakhire > 0)
						{
							t1.a_asli[t1.aSize_asli++] = t1.g_zakhire[--t1.gSize_zakhire];
							t1.a_asli[t1.aSize_asli - 1].playingType = 'A';

						}
					}

					while (t1.dSize_asli < 4)
					{
						if (t1.mSize_zakhire > 0)
						{
							t1.d_asli[t1.dSize_asli++] = t1.m_zakhire[--t1.mSize_zakhire];
							t1.d_asli[t1.dSize_asli - 1].playingType = 'D';
						}
						else if (t1.aSize_zakhire > 0)
						{
							t1.d_asli[t1.dSize_asli++] = t1.a_zakhire[--t1.aSize_zakhire];
							t1.d_asli[t1.dSize_asli - 1].playingType = 'D';

						}
						else if (t1.gSize_zakhire > 0)
						{
							t1.d_asli[t1.dSize_asli++] = t1.g_zakhire[--t1.gSize_zakhire];
							t1.d_asli[t1.dSize_asli - 1].playingType = 'D';

						}
					}

					while (t1.gSize_asli < 1)
					{
						if (t1.mSize_zakhire > 0)
						{
							t1.g_asli[t1.gSize_asli++] = t1.m_zakhire[--t1.mSize_zakhire];
							t1.g_asli[t1.gSize_asli - 1].playingType = 'G';
						}
						else if (t1.dSize_zakhire > 0)
						{
							t1.g_asli[t1.gSize_asli++] = t1.d_zakhire[--t1.dSize_zakhire];
							t1.g_asli[t1.gSize_asli - 1].playingType = 'G';

						}
						else if (t1.aSize_zakhire > 0)
						{
							t1.g_asli[t1.gSize_asli++] = t1.a_zakhire[--t1.aSize_zakhire];
							t1.g_asli[t1.gSize_asli - 1].playingType = 'G';

						}
					}

					while (t1.mSize_asli < 4)
					{
						if (t1.dSize_zakhire > 0)
						{
							t1.m_asli[t1.mSize_asli++] = t1.d_zakhire[--t1.dSize_zakhire];
							t1.m_asli[t1.mSize_asli - 1].playingType = 'M';
						}
						else if (t1.aSize_zakhire > 0)
						{
							t1.m_asli[t1.mSize_asli++] = t1.a_zakhire[--t1.aSize_zakhire];
							t1.m_asli[t1.mSize_asli - 1].playingType = 'M';

						}
						else if (t1.gSize_zakhire > 0)
						{
							t1.m_asli[t1.mSize_asli++] = t1.g_zakhire[--t1.gSize_zakhire];
							t1.m_asli[t1.mSize_asli - 1].playingType = 'M';

						}
					}

					T[teamSize++] = t1;
				}
			}
		}
		closedir(pDIR);
	}

	srand(time(NULL));
	int t = (rand() % 10) + 10;
	for (int i = 0; i < t; i++)
	{
		int x1 = rand() % teamSize;
		int x2 = rand() % teamSize;
		swap(T[x1], T[x2]);
	}

	FILE *fp1 = fopen("League_Schedule.txt", "r");
	if (fp1 == NULL)
	{
		printf("FILE SCHEDULING NOT FOUND");
		system("pause");
		return 0;
	}

	schedul schedules[30][8];
	int a1, a2, a3;
	for (int i = 0; fscanf(fp1, "%d%d%d", &a1, &a2, &a3) != EOF; i++)
	{

		i %= 8;
		schedules[a1 - 1][i].team1Index = a2;
		schedules[a1 - 1][i].team2Index = a3;
	}
	fclose(fp1);
	FILE *save = fopen("save.txt", "r");
	FILE *fpscore = fopen("score.txt", "r");
	FILE *fpn = fopen("nproceed.txt", "r");
	int n;
	int current;
	if (save != NULL)
	{
		printf("Please select:\n");
		printf("1. New league\n");
		printf("2. Continue previous league\n");
		int command;
		scanf("%d", &command);
		while (command != 1 && command != 2)
		{
			printf("Please enter the correct number");
			scanf("%d", &command);
		}
		if (command == 1)
			save = NULL;
	}
	if (save == NULL)
	{
		printf("For start new league\n");
		system("pause");
		system("cls");
		printf("Please choose one of the folowing teams\n");
		for (int i = 0; i < 16; i++)
		{
			printf("%d. %s\n", i + 1, T[i].name);
		}

		scanf("%d", &current);
		while (current > teamSize)
		{
			printf("Invalid number\n");
			printf("Please re enter correct number\n");
			scanf("%d", &current);
			system("cls");
		}
		current--;

	}
	else
	{
		FILE* fpsave = fopen("save.txt", "r");
		for (int i = 0; i < teamSize; i++)
		{
			char tname[30];
			fscanf(fpsave, "%s", tname);
			if (strcmp(tname, T[i].name) != 0)
			{
				int j;
				for (j = i + 1; j < teamSize; j++)
				{
					if (strcmp(T[j].name, tname) == 0)
						break;
				}
				swap(T[i], T[j]);
			}
			fscanf(fpsave, "%d%d%d%d", &T[i].score, &T[i].numberOfWin, &T[i].numberOfEqual, &T[i].numberOfLoose);
		}
		fclose(fpsave);
		FILE* fpteam = fopen("team.txt", "r");
		fscanf(fpteam, "%d", &current);
		fclose(fpteam);
	}

	while (true)
	{
		printf("Please choose one of the folowing iteams below\n");
		printf("1. Show score table\n");
		printf("2. Show Scheduling\n");
		printf("3. line up\n");
		printf("4. Arrange team\n");
		printf("5. proceed\n");
		printf("6. Table\n");
		printf("7. Save\n");
		printf("8. Exit\n");
		int com;
		scanf("%d", &com);
		switch (com)
		{
		case 1:
		{
			//int T[schedules[-1][j].team1Index - 1].goalzade;
			for (int i = 0; i < n; i++) {
				printf("*******************************\n\n");
				printf("Hafte %d : \n\n", i + 1);
				for (int j = 0; j < 8; j++) {
					int maxc = strlen(T[schedules[i][j].team1Index - 1].name);
					printf("%s %d       %d %s\n", T[schedules[i][j].team1Index - 1].name, T[schedules[i][j].team1Index - 1].goalpermatch[i], T[schedules[i][j].team2Index - 1].goalpermatch[i], T[schedules[i][j].team2Index - 1].name);
				}
			}


		}
		break;
		case 2:
		{
			int maxc = 0;
			for (int i = 0; i < 30; i++)
			{

				printf("*******************************\n\n");
				printf("Hafte %d : \n\n", i + 1);
				for (int j = 0; j < 8; j++)
				{
					maxc = strlen(T[schedules[i][j].team1Index - 1].name);

					printf("%s", T[schedules[i][j].team1Index - 1].name);
					for (int space = 0; space < 20 - maxc; space++)
						printf(" ");
					printf("  vs          %s\n", T[schedules[i][j].team2Index - 1].name);

				}
				printf("\n\n");
			}
		}
		break;
		case 3:
		{
			printf("GOALKEEPERS\n");
			for (int i = 0; i < T[current].gSize; i++)
			{

				printf("%d-%s : %c -> %c\n\n", T[current].g[i].number, T[current].g[i].name, T[current].g[i].type, T[current].g[i].playingType);
				printf("Skill : %d\n\n", T[current].g[i].skill);
				printf("Fitness : %d\n\n", T[current].g[i].fitness);
				printf("Form : %d\n\n", T[current].g[i].form);
			}
			printf("DEFENDERS\n");
			for (int i = 0; i < T[current].dSize; i++)
			{

				printf("%s : %c -> %c\n\n", T[current].d[i].name, T[current].d[i].type, T[current].d[i].playingType);
				printf("Skill : %d\n\n", T[current].d[i].skill);
				printf("Fitness : %d\n\n", T[current].d[i].fitness);
				printf("Form : %d\n\n", T[current].d[i].form);
			}
			printf("MIDFIELDERS\n");
			for (int i = 0; i < T[current].mSize; i++)
			{

				printf("%s : %c -> %c\n\n", T[current].m[i].name, T[current].m[i].type, T[current].m[i].playingType);
				printf("Skill : %d\n\n", T[current].m[i].skill);
				printf("Fitness : %d\n\n", T[current].m[i].fitness);
				printf("Form : %d\n\n", T[current].m[i].form);
			}
			printf("ATTACKERS\n");
			for (int i = 0; i < T[current].aSize; i++)
			{

				printf("%s : %c -> %c\n\n", T[current].a[i].name, T[current].a[i].type, T[current].a[i].playingType);
				printf("Skill : %d\n\n", T[current].a[i].skill);
				printf("Fitness : %d\n\n", T[current].a[i].fitness);
				printf("Form: %d\n\n", T[current].a[i].form);

			}




		}
		break;
		case 4:
		{
			bool isArrenging = true;
			while (isArrenging)
			{
				printf("Team current plan : %s\n", T[current].plan);
				printf("Main team: \n\n");
				printf("\nAttackers:\n");
				for (int i = 0; i < T[current].aSize_asli; i++)
				{
					printf("%s      skil = %d \n", T[current].a_asli[i].name,T[current].a_asli[i].skill);
				}
				printf("\nMidfielders:\n");
				for (int i = 0; i < T[current].mSize_asli; i++)
				{
					printf("%s      skil = %d \n", T[current].m_asli[i].name,T[current].m_asli[i].skill);
				}
				printf("\nDefencers:\n");
				for (int i = 0; i < T[current].dSize_asli; i++)
				{
					printf("%s      skil = %d \n", T[current].d_asli[i].name, T[current].d_asli[i].skill);
				}
				printf("\nGoal keeper:\n");
				for (int i = 0; i < T[current].gSize_asli; i++)
				{
					printf("%s      skil = %d \n", T[current].g_asli[i].name, T[current].g_asli[i].skill);
				}
				printf("Please choose one of the folowing iteams below\n");
				printf("1. re-arrange team\n");
				printf("2. change plan\n");
				printf("3. Main menu\n");
				int com1;
				scanf("%d", &com);
				switch (com)
				{
				case 1:
				{
					bool isSelecting = true;
					char selectedPlayer1Type;
					int selectedPlayer1Index;
					while (isSelecting)
					{
						printf("select from one of the fields below to choose player\n");
						printf("1. Goal keeper\n");
						printf("2. Midfielder\n");
						printf("3. Defender\n");
						printf("4. Attacker\n");
						int com2;
						scanf("%d", &com2);
						if (com2 == 1)
						{
							if (T[current].gSize_zakhire == 0)
							{
								printf("There is no substitute goalkeeper\n");
								continue;
							}
							selectedPlayer1Type = 'G';
							printf("select from one of the players below\n");
							for (int i = 0; i < T[current].gSize_zakhire; i++)
							{
								printf("%d : %s      skil = %d \n", i + 1, T[current].g_zakhire[i].name, T[current].g_zakhire[i].skill);
							}
							scanf("%d", &selectedPlayer1Index);
							while (selectedPlayer1Index > T[current].gSize_zakhire || selectedPlayer1Index < 1)
							{
								printf("Please select player correctly\n");
								scanf("%d", &selectedPlayer1Index);
							}
							selectedPlayer1Index--;
							isSelecting = false;

						}
						else if (com2 == 2)
						{
							if (T[current].mSize_zakhire == 0)
							{
								printf("There is no substitute midfielders\n");
								continue;
							}
							
							selectedPlayer1Type = 'M';
							printf("select from one of the players below\n");
							
							
							for (int i = 0; i < T[current].mSize_zakhire; i++)
							{
								printf("%d : %s      skil = %d \n", i + 1, T[current].m_zakhire[i].name,T[current].m_zakhire[i].skill);
								
							}
							scanf("%d", &selectedPlayer1Index);
							while (selectedPlayer1Index > T[current].mSize_zakhire || selectedPlayer1Index < 1)
							{
								printf("Please select player correctly\n");
								scanf("%d", &selectedPlayer1Index);
							}
							selectedPlayer1Index--;
							isSelecting = false;
						}
						else if (com2 == 3)
						{
							if (T[current].dSize_zakhire == 0)
							{
								printf("There is no substitute defender\n");
								continue;
							}
							selectedPlayer1Type = 'D';
							printf("select from one of the players below\n");
							for (int i = 0; i < T[current].dSize_zakhire; i++)
							{
								printf("%d : %s      skil = %d \n", i + 1, T[current].d_zakhire[i].name, T[current].d_zakhire[i].skill);
							}
							scanf("%d", &selectedPlayer1Index);
							while (selectedPlayer1Index > T[current].dSize_zakhire || selectedPlayer1Index < 1)
							{
								printf("Please select player correctly\n");
								scanf("%d", &selectedPlayer1Index);
							}
							selectedPlayer1Index--;
							isSelecting = false;
						}
						else if (com2 == 4)
						{
							if (T[current].aSize_zakhire == 0)
							{
								printf("There is no substitute attackers\n");
								continue;
							}
							selectedPlayer1Type = 'A';
							printf("select from one of the players below\n");
							for (int i = 0; i < T[current].aSize_zakhire; i++)
							{
								printf("%d : %s      skil = %d \n", i + 1, T[current].a_zakhire[i].name, T[current].a_zakhire[i].skill);
							}
							scanf("%d", &selectedPlayer1Index);
							while (selectedPlayer1Index > T[current].aSize_zakhire || selectedPlayer1Index < 1)
							{
								printf("Please select player correctly\n");
								scanf("%d", &selectedPlayer1Index);
							}
							selectedPlayer1Index--;
							isSelecting = false;
						}
					}

					char selectedPlayer2Type;
					int selectedPlayer2Index;
					isSelecting = true;

					while (isSelecting)
					{
						printf("select from one of the fields below to choose player and swap substitute with\n");
						printf("1. Goal keeper\n");
						printf("2. Midfielder\n");
						printf("3. Defender\n");
						printf("4. Attacker\n");
						int com2;
						scanf("%d", &com2);
						if (com2 == 1)
						{
							selectedPlayer2Type = 'G';
							printf("select from one of the players below\n");
							for (int i = 0; i < T[current].gSize_asli; i++)
							{
								printf("%d : %s      skil = %d\n", i + 1, T[current].g_asli[i].name , T[current].g_asli[i].skill);
							}
							scanf("%d", &selectedPlayer2Index);
							while (selectedPlayer2Index > T[current].gSize_asli || selectedPlayer2Index < 1)
							{
								printf("Please select player correctly\n");
								scanf("%d", &selectedPlayer2Index);
							}
							selectedPlayer2Index--;
							isSelecting = false;

						}
						else if (com2 == 2)
						{
							selectedPlayer2Type = 'M';
							printf("select from one of the players below\n");
							for (int i = 0; i < T[current].mSize_asli; i++)
							{
								printf("%d : %s      skil = %d\n", i + 1, T[current].m_asli[i].name,T[current].m_asli[i].skill);
							}
							scanf("%d", &selectedPlayer2Index);
							while (selectedPlayer2Index > T[current].mSize_asli || selectedPlayer2Index < 1)
							{
								printf("Please select player correctly\n");
								scanf("%d", &selectedPlayer2Index);
							}
							selectedPlayer2Index--;
							isSelecting = false;
						}
						else if (com2 == 3)
						{
							selectedPlayer2Type = 'D';
							printf("select from one of the players below\n");
							for (int i = 0; i < T[current].dSize_asli; i++)
							{
								printf("%d : %s      skil = %d\n", i + 1, T[current].d_asli[i].name, T[current].d_asli[i].skill);
							}
							scanf("%d", &selectedPlayer2Index);
							while (selectedPlayer2Index > T[current].dSize_asli || selectedPlayer2Index < 1)
							{
								printf("Please select player correctly\n");
								scanf("%d", &selectedPlayer2Index);
							}
							selectedPlayer2Index--;
							isSelecting = false;
						}
						else if (com2 == 4)
						{
							selectedPlayer2Type = 'A';
							printf("select from one of the players below\n");
							for (int i = 0; i < T[current].aSize_asli; i++)
							{
								printf("%d : %s      skil = %d\n", i + 1, T[current].a_asli[i].name, T[current].a_asli[i].skill);
							}
							scanf("%d", &selectedPlayer2Index);
							while (selectedPlayer2Index > T[current].aSize_asli || selectedPlayer2Index < 1)
							{
								printf("Please select player correctly\n");
								scanf("%d", &selectedPlayer2Index);
							}
							selectedPlayer2Index--;
							isSelecting = false;
						}
					}
					printf("%c %c\n", selectedPlayer1Type, selectedPlayer2Type);
					if (selectedPlayer1Type == 'A')
					{
						T[current].a_asli[selectedPlayer2Index].playingType = 'A';
						if (selectedPlayer2Type == 'A')
						{
							T[current].a_zakhire[selectedPlayer1Index].playingType = 'A';
							swap(T[current].a_zakhire[selectedPlayer1Index], T[current].a_asli[selectedPlayer2Index]);
						}
						else if (selectedPlayer2Type == 'D')
						{
							T[current].d_zakhire[selectedPlayer1Index].playingType = 'D';
							swap(T[current].a_zakhire[selectedPlayer1Index], T[current].d_asli[selectedPlayer2Index]);
							T[current].d_asli[selectedPlayer2Index].skill -= 40;
						}
						else if (selectedPlayer2Type == 'G')
						{
							T[current].g_zakhire[selectedPlayer1Index].playingType = 'G';
							swap(T[current].a_zakhire[selectedPlayer1Index], T[current].g_asli[selectedPlayer2Index]);
							T[current].g_asli[selectedPlayer2Index].skill -= 60;
						}
						else if (selectedPlayer2Type == 'M')
						{
							T[current].m_zakhire[selectedPlayer1Index].playingType = 'M';
							swap(T[current].a_zakhire[selectedPlayer1Index], T[current].m_asli[selectedPlayer2Index]);
							T[current].m_asli[selectedPlayer2Index].skill -= 10;

						}
					}
					else if (selectedPlayer1Type == 'D')
					{

						T[current].d_asli[selectedPlayer2Index].playingType = 'D';
						if (selectedPlayer2Type == 'A')
						{
							T[current].a_zakhire[selectedPlayer1Index].playingType = 'A';
							swap(T[current].d_zakhire[selectedPlayer1Index], T[current].a_asli[selectedPlayer2Index]);
							T[current].a_asli[selectedPlayer2Index].skill -= 40;
						}
						else if (selectedPlayer2Type == 'D')
						{
							T[current].d_zakhire[selectedPlayer1Index].playingType = 'D';
							swap(T[current].d_zakhire[selectedPlayer1Index], T[current].d_asli[selectedPlayer2Index]);
						}
						else if (selectedPlayer2Type == 'G')
						{
							T[current].g_zakhire[selectedPlayer1Index].playingType = 'G';
							swap(T[current].d_zakhire[selectedPlayer1Index], T[current].g_asli[selectedPlayer2Index]);
							T[current].g_asli[selectedPlayer2Index].skill -= 30;

						}
						else if (selectedPlayer2Type == 'M')
						{
							T[current].m_zakhire[selectedPlayer1Index].playingType = 'M';
							swap(T[current].d_zakhire[selectedPlayer1Index], T[current].m_asli[selectedPlayer2Index]);
							T[current].m_asli[selectedPlayer2Index].skill -= 20;

						}
					}
					else if (selectedPlayer1Type == 'G')
					{

						T[current].g_asli[selectedPlayer2Index].playingType = 'G';
						T[current].a_asli[selectedPlayer2Index].playingType = 'A';
						if (selectedPlayer2Type == 'A')
						{
							T[current].a_zakhire[selectedPlayer1Index].playingType = 'A';
							swap(T[current].g_zakhire[selectedPlayer1Index], T[current].a_asli[selectedPlayer2Index]);
							T[current].a_asli[selectedPlayer2Index].skill -= 50;

						}
						else if (selectedPlayer2Type == 'D')
						{
							T[current].d_zakhire[selectedPlayer1Index].playingType = 'D';
							swap(T[current].g_zakhire[selectedPlayer1Index], T[current].d_asli[selectedPlayer2Index]);
							T[current].d_asli[selectedPlayer2Index].skill -= 40;

						}
						else if (selectedPlayer2Type == 'G')
						{
							T[current].g_zakhire[selectedPlayer1Index].playingType = 'G';
							swap(T[current].g_zakhire[selectedPlayer1Index], T[current].g_asli[selectedPlayer2Index]);

						}
						else if (selectedPlayer2Type == 'M')
						{
							T[current].m_zakhire[selectedPlayer1Index].playingType = 'M';
							swap(T[current].g_zakhire[selectedPlayer1Index], T[current].m_asli[selectedPlayer2Index]);
							T[current].m_asli[selectedPlayer2Index].skill -= 30;

						}
					}
					else if (selectedPlayer1Type == 'M')
					{
						T[current].m_asli[selectedPlayer2Index].playingType = 'M';
						if (selectedPlayer2Type == 'A')
						{
							T[current].a_zakhire[selectedPlayer1Index].playingType = 'A';
							swap(T[current].m_zakhire[selectedPlayer1Index], T[current].a_asli[selectedPlayer2Index]);
							T[current].a_asli[selectedPlayer2Index].skill -= 10;

						}
						else if (selectedPlayer2Type == 'D')
						{
							T[current].d_zakhire[selectedPlayer1Index].playingType = 'D';
							swap(T[current].m_zakhire[selectedPlayer1Index], T[current].d_asli[selectedPlayer2Index]);
							T[current].d_asli[selectedPlayer2Index].skill -= 20;

						}
						else if (selectedPlayer2Type == 'G')
						{
							T[current].g_zakhire[selectedPlayer1Index].playingType = 'G';
							swap(T[current].m_zakhire[selectedPlayer1Index], T[current].g_asli[selectedPlayer2Index]);
							T[current].d_asli[selectedPlayer2Index].skill -= 50;

						}
						else if (selectedPlayer2Type == 'M')
						{
							T[current].m_zakhire[selectedPlayer1Index].playingType = 'M';
							swap(T[current].m_zakhire[selectedPlayer1Index], T[current].m_asli[selectedPlayer2Index]);
						}
					}
					
					system("cls");

				}
				break;
				case 2:
				{
					printf("Please select one of the folowing plans\n");
					printf("1. 4-4-2\n");
					printf("2. 5-4-1\n");
					printf("3. 4-3-3\n");
					int com4;
					scanf("%d", &com4);
					
					while (com4 > 3 && com4 < 1)
					{
						printf("Please enter number correctly");
						scanf("%d", &com4);
					}
					if (strcmp(T[current].plan, "4-4-2") == 0)
					{
						if (com4 == 2)
						{
							T[current].d_asli[T[current].dSize_asli++] = T[current].a_asli[1];
							T[current].aSize_asli--;
							strcpy(T[current].plan, "5-4-1");
						}
						else if (com4 == 3)
						{
							T[current].a_asli[T[current].aSize_asli++] = T[current].m_asli[2];
							T[current].mSize_asli--;
							strcpy(T[current].plan, "4-3-3");
						}
					}
					else if (strcmp(T[current].plan, "5-4-1") == 0)
					{
						if (com4 == 1)
						{
							T[current].a_asli[T[current].aSize_asli++] = T[current].d_asli[4];
							T[current].dSize_asli--;
							strcpy(T[current].plan, "4-4-2");
						}
						else if (com4 == 3)
						{
							T[current].a_asli[T[current].aSize_asli++] = T[current].d_asli[4];
							T[current].dSize_asli--;
							T[current].a_asli[T[current].aSize_asli++] = T[current].m_asli[2];
							T[current].mSize_asli--;
							strcpy(T[current].plan, "4-3-3");

						}
					}
					else if (strcmp(T[current].plan, "4-3-3") == 0)
					{
						if (com4 == 1)
						{
							T[current].m_asli[T[current].mSize_asli++] = T[current].a_asli[2];
							T[current].aSize_asli--;
							strcpy(T[current].plan, "4-4-2");
						}
						else if (com4 == 2)
						{
							T[current].m_asli[T[current].mSize_asli++] = T[current].a_asli[2];
							T[current].aSize_asli--;
							T[current].d_asli[T[current].dSize_asli++] = T[current].a_asli[1];
							T[current].aSize_asli--;
							strcpy(T[current].plan, "5-4-1");
						}
					}
			
					system("cls");
				}
				break;
				case 3:
				{
					isArrenging = false;
				}
				default:
					break;
				}
			}
		}
		break;
		case 5:
		{

			printf("Please enter n(number of weeks)\n");
			scanf("%d", &n);
			for (int i = 0; i < n; i++)
			{
				for (int j = 0; j < 8; j++)
				{
					int firstTeamAttackersPoint = 0, firstTeamDefendersPoint = 0;
					int secondTeamAttackersPoint = 0, secondTeamDefendersPOint = 0;

					for (int k = 0; k < T[schedules[i][j].team1Index].aSize_asli; k++)
					{
						firstTeamAttackersPoint += 2 * T[schedules[i][j].team1Index-1].a_asli[k].skill;
						firstTeamAttackersPoint += 1 * T[schedules[i][j].team1Index-1].a_asli[k].fitness;
						firstTeamAttackersPoint += 1 * T[schedules[i][j].team1Index-1].a_asli[k].form;
					}

					for (int k = 0; k < T[schedules[i][j].team2Index].aSize_asli; k++)
					{
						secondTeamAttackersPoint += 2 * T[schedules[i][j].team2Index-1].a_asli[k].skill;
						secondTeamAttackersPoint += 1 * T[schedules[i][j].team2Index-1].a_asli[k].fitness;
						secondTeamAttackersPoint += 1 * T[schedules[i][j].team2Index-1].a_asli[k].form;
					}

					for (int k = 0; k < T[schedules[i][j].team1Index-1].dSize_asli; k++)
					{
						firstTeamDefendersPoint += 2 * T[schedules[i][j].team1Index-1].d_asli[k].skill;
						firstTeamDefendersPoint += 1 * T[schedules[i][j].team1Index-1].d_asli[k].fitness;
						firstTeamDefendersPoint += 1 * T[schedules[i][j].team1Index-1].d_asli[k].form;
					}

					for (int k = 0; k < T[schedules[i][j].team2Index-1].dSize_asli; k++)
					{
						secondTeamDefendersPOint += 2 * T[schedules[i][j].team2Index-1].d_asli[k].skill;
						secondTeamDefendersPOint += 1 * T[schedules[i][j].team2Index-1].d_asli[k].fitness;
						secondTeamDefendersPOint += 1 * T[schedules[i][j].team2Index-1].d_asli[k].form;
					}

					int chance1 = 0;
					chance1 += (firstTeamAttackersPoint - secondTeamAttackersPoint);
					chance1 += (secondTeamDefendersPOint - firstTeamAttackersPoint);
					int goals1, goals2;
					if (chance1 > 0)
					{
						goals1 = (rand() % (6));
						goals2 = (rand() % (2));
					}
					else if (chance1 == 0)
					{
						goals1 = (rand() % (2));
						goals2 = (rand() % (2));
					}
					else
					{
						chance1 *= 1;
						goals2 = (rand() % 6);
						goals1 = (rand() % (2));
					}
					if (goals1 > goals2)
					{
						T[schedules[i][j].team1Index-1].score += 3;
						T[schedules[i][j].team1Index-1].numberOfWin++;
						T[schedules[i][j].team2Index-1].numberOfLoose++;

						//Form time barande bayaad ziad she
						for (int l = 0; l < 5; l++) {
							T[schedules[i][j].team1Index-1].a_asli[l].form += 5;
							T[schedules[i][j].team1Index-1].m_asli[l].form += 5;
							T[schedules[i][j].team1Index-1].d_asli[l].form += 5;
							T[schedules[i][j].team1Index-1].g_asli[l].form += 5;
						}
						//form time bazande bayad kam she
						for (int l = 0; l < 5; l++) {
							T[schedules[i][j].team2Index-1].a_asli[l].form -= 5;
							T[schedules[i][j].team2Index-1].m_asli[l].form -= 5;
							T[schedules[i][j].team2Index-1].d_asli[l].form -= 5;
							T[schedules[i][j].team2Index-1].g_asli[l].form -= 5;

						}
					}
					else if (goals1 == goals2)
					{
						T[schedules[i][j].team1Index-1].score++;
						T[schedules[i][j].team2Index-1].score++;
						T[schedules[i][j].team1Index-1].numberOfEqual++;
						T[schedules[i][j].team2Index-1].numberOfEqual++;





					}
					else
					{
						T[schedules[i][j].team2Index-1].score += 3;
						T[schedules[i][j].team2Index-1].numberOfWin++;
						T[schedules[i][j].team1Index-1].numberOfLoose++;
						//Form time barande bayaad ziad she
						for (int l = 0; l < 5; l++) {
							T[schedules[i][j].team2Index-1].a_asli[l].form += 5;
							T[schedules[i][j].team2Index-1].m_asli[l].form += 5;
							T[schedules[i][j].team2Index-1].d_asli[l].form += 5;
							T[schedules[i][j].team2Index-1].g_asli[l].form += 5;
						}
						//form time bazande bayad kam she
						for (int l = 0; l < 5; l++) {
							T[schedules[i][j].team1Index-1].a_asli[l].form -= 5;
							T[schedules[i][j].team1Index-1].m_asli[l].form -= 5;
							T[schedules[i][j].team1Index-1].d_asli[l].form -= 5;
							T[schedules[i][j].team1Index-1].g_asli[l].form -= 5;
						}
					}
					T[schedules[i][j].team1Index-1].tafazol += goals1;
					T[schedules[i][j].team1Index-1].goalzade += goals1;
					T[schedules[i][j].team1Index-1].goalpermatch[i] = goals1;
					T[schedules[i][j].team2Index-1].goalpermatch[i] = goals2;
					T[schedules[i][j].team1Index-1].tafazol -= goals2;
					T[schedules[i][j].team1Index-1].goalkhorde += goals2;

					T[schedules[i][j].team2Index-1].tafazol -= goals1;
					T[schedules[i][j].team2Index-1].goalkhorde += goals1;

					T[schedules[i][j].team2Index-1].tafazol += goals2;
					T[schedules[i][j].team2Index-1].goalzade += goals2;
					//Fitness asli haye 2 tim bayad kam she
					for (int l = 0; l < 5; l++) {
						T[schedules[i][j].team2Index-1].a_asli[l].fitness -= 5;
						T[schedules[i][j].team2Index-1].m_asli[l].fitness -= 5;
						T[schedules[i][j].team2Index-1].d_asli[l].fitness -= 5;
						T[schedules[i][j].team2Index-1].g_asli[l].fitness -= 5;

						T[schedules[i][j].team1Index-1].a_asli[l].fitness -= 5;
						T[schedules[i][j].team1Index-1].m_asli[l].fitness -= 5;
						T[schedules[i][j].team1Index-1].d_asli[l].fitness -= 5;
						T[schedules[i][j].team1Index-1].g_asli[l].fitness -= 5;
					}
					//Taviziha
					for (int l = 0; l < 5; l++) {
						T[schedules[i][j].team2Index-1].a_zakhire[l].form -= 5;
						T[schedules[i][j].team2Index-1].m_zakhire[l].form -= 5;
						T[schedules[i][j].team2Index-1].d_zakhire[l].form -= 5;
						T[schedules[i][j].team2Index-1].g_zakhire[l].form -= 5;

						T[schedules[i][j].team1Index-1].a_zakhire[l].form -= 5;
						T[schedules[i][j].team1Index-1].m_zakhire[l].form -= 5;
						T[schedules[i][j].team1Index-1].d_zakhire[l].form -= 5;
						T[schedules[i][j].team1Index-1].g_zakhire[l].form -= 5;
					}

				}
			}
		}
		break;
		case 6:
		{
			int MAX = 18;
			for (int i = 0; i < teamSize; i++)
			{
				if (strlen(T[i].name) > MAX)
					MAX = strlen(T[i].name);
			}
			printf("Team name");

			for (int i = 0; i < MAX - 9; i++)
			{
				printf(" ");
			}
			printf("team score   team wins   team equal   team looses   goal differeance   goalzade  goalkhorde \n");
			for (int i = 0; i < teamSize; i++)
			{
				T1[i] = T[i];
			}
			for (int i = 0; i < teamSize; i++)
			{
				for (int j = 0; j < teamSize - 1; j++)
				{
					if (T1[j].score < T1[j + 1].score)
					{
						swap(T1[j], T1[j + 1]);
					}
					else if (T1[j].score == T1[j + 1].score)
					{
						if (T1[j].tafazol < T1[j + 1].tafazol)
						{
							swap(T1[j], T1[j + 1]);
						}
					}
				}
			}
			for (int i = 0; i < teamSize; i++)
			{
				printf("%d-%s",i+1, T1[i].name);
				int tmp1 = strlen(T1[i].name);
				for (int j = 0; j < MAX - tmp1; j++)
				{
					printf(" ");
				}
				printf("       %d           %d          %d           %d              %d               %d             %d\n", T1[i].score, T1[i].numberOfWin, T1[i].numberOfEqual, T1[i].numberOfLoose, T1[i].tafazol, T1[i].goalzade, T1[i].goalkhorde);
			}
		}
		break;
		case 7:
		{
			FILE * fpsave = fopen("save.txt", "w");
			for (int i = 0; i < teamSize; i++)
			{
				fprintf(fpsave, "%s %d %d %d %d\n", T[i].name, T[i].score, T[i].numberOfWin, T[i].numberOfEqual, T[i].numberOfLoose);
			}
			fclose(fpsave);
			FILE* fpteam = fopen("team.txt", "w");
			fprintf(fpteam, "%d\n%s", current, T[current].plan);
			fclose(fpteam);
			FILE *fpscore = fopen("score.txt", "a");
			for (int i = 0; i < n; i++) {
				for (int j = 0; j < 8; j++)
				fprintf(fpscore,"%s %d  %d %s\n", T[schedules[i][j].team1Index - 1].name, T[schedules[i][j].team1Index - 1].goalpermatch[i], T[schedules[i][j].team2Index - 1].goalpermatch[i], T[schedules[i][j].team2Index - 1].name);
			}
			FILE *fpn = fopen("nproceed.txt", "w");
			fprintf(fpn, "%d", n);
		
		
			/*FILE *fpteamA = fopen("teamA.txt", "w");
			for (int i = 0; i < T[current].aSize_asli; i++)
			{
			fprintf(fpteamA, "%s\n", T[current].a_asli[i].name);
			}

			fclose(fpteamA);
			FILE *fpteamD = fopen("teamD.txt", "w");
			for (int i = 0; i < T[current].dSize_asli; i++)
			{
			fprintf(fpteamD, "%s\n", T[current].d_asli[i].name);
			}
			fclose(fpteamD);
			FILE *fpteamG = fopen("teamG.txt", "w");
			for (int i = 0; i < T[current].gSize_asli; i++)
			{
			fprintf(fpteamG, "%s\n", T[current].g_asli[i].name);
			}
			fclose(fpteamG);
			FILE *fpteamM = fopen("teamM.txt", "w");
			for (int i = 0; i < T[current].mSize_asli; i++)
			{
			fprintf(fpteamM, "%s\n", T[current].m_asli[i].name);
			}
			fclose(fpteamM);*/

		}
		break;
		case 8:
		{
			return 0;
		}
		default:
			break;
		}
		system("pause");
		system("cls");
	}
}